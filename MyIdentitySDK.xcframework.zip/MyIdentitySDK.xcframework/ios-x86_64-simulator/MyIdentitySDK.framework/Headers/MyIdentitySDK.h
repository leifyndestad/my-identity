//
//  MyIdentitySDK.h
//  MyIdentitySDK
//
//  Created by Leif Yndestad on 15/09/2020.
//  Copyright © 2020 EVRY Card Services AS. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MyIdentitySDK.
FOUNDATION_EXPORT double MyIdentitySDKVersionNumber;

//! Project version string for MyIdentitySDK.
FOUNDATION_EXPORT const unsigned char MyIdentitySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyIdentitySDK/PublicHeader.h>


