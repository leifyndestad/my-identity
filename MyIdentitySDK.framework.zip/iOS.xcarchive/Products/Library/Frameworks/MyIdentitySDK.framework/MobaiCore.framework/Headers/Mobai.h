//
//  Mobai.h
//  Mobai
//
//  Created by Martin Stokkenes on 15/09/2020.
//  Copyright © 2020 Mobai. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Mobai.
FOUNDATION_EXPORT double MobaiVersionNumber;

//! Project version string for Mobai.
FOUNDATION_EXPORT const unsigned char MobaiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mobai/PublicHeader.h>


